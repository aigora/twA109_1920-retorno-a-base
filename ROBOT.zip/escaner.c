
/*

ROBOT CON RADAR 360 GRADOS QUE SE MUEVE POR UNA GEOMETRIA DADA
VERSION 2 25-5-2020

Uso: %s [<tiempo maximo>] [<rumbo inicial>] [<x inicial>] [<y inicial>] [<nombre fichero>]

FUNCIONES ASOCIADAS Y BUCLE MAIN
NO INCLUYE LA FUNCION DEL ALGORITMO DEL ROBOT QUE CALCULA SU VELOCIDAD ANGULAR Y RADIAL - EN ROBOT.C

lee geometria de un fichero
dibuja geometria de la habitacion en ventana 0
escanea geometria desde la posicion y orientacion del robot
plotea el escaneo en ventana 2
dibuja la geometria detectada en el escaneo en ventana 1

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "gfx2.h"				// libreria de funciones de dibujo muy sencilla


#define MAXLINEAS 100				// maximo de lineas en un fichero de geometria
#define PUNTOSESCANEO 1000			// puntos escaneados en los 360 grados
#define PERIODO 100.0				// periodo de repetición de escaneo y algoritmo robot en milisegundos
#define TMAX 50000				// fin simulacion en milisegundos, si no se da en linea de comando
#define RANGO 10000.0				// maxima distancia de alcance del escaner
#define NOMBREFICHERO "./habitacion.txt"	// nombre del fichero de geometria, si no se da en linea de comando


// estructura con los puntos iniciales y finales y pendiente de una linea de la geometria de la habitacion
struct linea{
	float x1;
	float y1;
	float x2;
	float y2;
	float m;	// pendiente de la recta
};

// estructura devuelta por el algoritmo del robot, que dice al programa principal la velocidad a la que se mueve en cada ciclo
struct estadorobot{
	float velocidad_radial;
	float velocidad_angular;
	char resultado[100];			// cadena de texto devuelta por el robot con la descripcion que se quiera
};

struct linea geometria[MAXLINEAS];		// array con las lineas de la geometria de la habitacion

float t[PUNTOSESCANEO];				// array con tangente del angulo de escaneo

struct estadorobot algoritmo_robot(float tiempo, float *escaneo);	// funcion algoritmo del robot, en robot.c

float escaneo[PUNTOSESCANEO];			// array de escaneo


void delay(int milisegundos)			// retraso de x milisegundos
{
	clock_t ahora,fin;

	fin = clock()+milisegundos*(CLOCKS_PER_SEC/1000);
	ahora = clock();

	do
	        ahora = clock();		
	while( ahora < fin );
}

// *************************************************************************
// CARGA DEL FICHERO DE DEFINICION DE GEOMETRIA
// FORMATO: X1 Y1 X2 Y2 DE CADA LINEA EN UNA LINEA DE TEXTO CON SEPARADOR UN ESPACIO

int leefichero(char *filename, struct linea *geometria)
{
    int cuentalineas=0;
    int i;
    float x1,y1,x2,y2;
    FILE *fp;
    
    fp = fopen(filename, "r");
    if (fp == NULL){
        printf("Could not open file %s",filename);
        return 0;
    }
    while (!feof(fp))
    {
	fscanf(fp,"%f %f %f %f\n",&x1,&y1,&x2,&y2);
	// ordena los dos puntos en orden creciente de la coordenada x
	if (x1<=x2){
		geometria[cuentalineas].x1=x1;
		geometria[cuentalineas].y1=y1;
		geometria[cuentalineas].x2=x2;
		geometria[cuentalineas].y2=y2;
	}
	else
	{
		geometria[cuentalineas].x1=x2;
		geometria[cuentalineas].y1=y2;
		geometria[cuentalineas].x2=x1;
		geometria[cuentalineas].y2=y1;
	}
	// calcula la pendiente de la linea y la guarda en .m
	if (x2==x1)
	{
		geometria[cuentalineas].m=1.0e12;  // no es pendiente infinita, pero casi
	}
	else	
	{
		geometria[cuentalineas].m=(geometria[cuentalineas].y2-geometria[cuentalineas].y1)/(geometria[cuentalineas].x2-geometria[cuentalineas].x1);
	}
        printf("(%f,%f)-(%f,%f)-%f\n",geometria[cuentalineas].x1,geometria[cuentalineas].y1,geometria[cuentalineas].x2,geometria[cuentalineas].y2,geometria	[cuentalineas].m);
	cuentalineas++;	
    }
    fclose(fp);

    return cuentalineas;		// devuelve el numero de lineas encontradas en el fichero
}


// ****************************************************************
// DIBUJA LA GEOMETRIA DE LA HABITACION

int dibujageometria(int numlineas,struct linea *geometria)
{
	int ysize = 400;		// tamano en y de la ventana
	int xsize = 400;		// tamano en x de la ventana
	int i;

	// Open a new window for drawing.
	gfx_open(0,xsize,ysize,"Geometria");

	// Set the current drawing color to green.
	gfx_color(0,0,200,100);

	// Dbuja las lineas del array geometria
	// en la ventana la posicion 0,0 es la esquina superior izquierda, y las y crecientes son hacia abajo
	// se transforman las coordenadas para que el punto 0,0 de la geometria este en el centro de la ventana y la y crezca hacia arriba
	for(i=0;i<numlineas;i++)
	{
		gfx_line(0,200+geometria[i].x1,200-geometria[i].y1,200+geometria[i].x2,200-geometria[i].y2);
	}
	gfx_color(0,240,0,0); // color rojo para el trayecto del robot 

	gfx_flush(0);
	return 0;

}

// ****************************************************
// grafica lineal del array de escaneado

int plotescaneo(float *escaneo)
{

	int i;

	gfx_clear(2);			// borra la ventana en cada ciclo para volver a pintarla

// el centro de la pantalla en PUNTOSESCANEO/2 corresponde a i=0; para la izquierda las i crecientes, el extremo derecho corresponde a PUNTOSESCANEO/2
// en vertical, si la distancia de escaneo es cero, se pinta el punto a una altura de 40 desde el borde 
	for(i=0;i<PUNTOSESCANEO;i++)
	{	
		gfx_point(2,(3*PUNTOSESCANEO/2-i)%PUNTOSESCANEO,360-escaneo[i]);
	}
	gfx_line(2,PUNTOSESCANEO/2,400,PUNTOSESCANEO/2,380);	// dibuja una linea vertical en el centro, como marcador de 0 grados
	gfx_flush(2);
	return 0;

}

// ****************************************************
// ESCANEA LA GEOMETRIA
// toma como entrada la posicion y orientacion del robot y la geometria de la habitacion
// guarda en el array escaneo para cada angulo de escaneo de 0 a 360 grados la distancia al elemento de geometria mas cercano

int escanear(float posx,float posy, float rumbo,float *escaneo,int numlineas,struct linea *geometria)
{
	int i;
	int l;
	int puntero;
	float distancia;
	float m;
	float xc,yc,xmin,ymin,xmax,ymax,yxmin,yxmax;
	float nuevadis;
	
	// el escaneo se realiza en el sistema de referencia de la habitacion: 0 grados es la horizontal
	// pero en el array escaneo se guarda a partir de la posicion marcada por puntero de forma que escaneo[0] corresponda
	// siempre a la direccion enfrente del robot (sistema de referencia del robot)
	// puntero se inicializa con la correspondencia de 0 grados en habitacion a -rumbo en el robot
	puntero=(PUNTOSESCANEO -(int) (rumbo*((float)PUNTOSESCANEO)/360.0)) % PUNTOSESCANEO;

	for(i=0;i<PUNTOSESCANEO;i++)
	{
		distancia=RANGO;			// se incializa con la distancia maxima de escaneo
		for(l=0;l<numlineas;l++)		// bucle que calcula la distancia a cada linea de la geometria
		{
			m=geometria[l].m;		// pendiente de la linea
			xmin=geometria[l].x1;		// puntos inicial y final de la linea
			xmax=geometria[l].x2;
			yxmin=geometria[l].y1;
			yxmax=geometria[l].y2;
			if (yxmin<=yxmax)		
			{
				ymin=yxmin;
				ymax=yxmax;
			}
			else
			{
				ymin=yxmax;
				ymax=yxmin;
			}

			// calculo del punto de inteseccion de la linea de la geometria y la linea desde el robot con el angulo de escaneado
			if (m!=t[i])			// no son paralelas, luego se cortan
			{
				xc=(posy-yxmin+m*xmin-t[i]*posx)/(m-t[i]);	// coordenada x del pnto de corte
				if (m>=1.0e11)					// linea vertical
					yc=posy+t[i]*(xc-posx);			// coordenada y del punto de corte con linea vertical
				else
					yc=yxmin+m*(xc-xmin);			// coordenada y del punto de corte con linea no vertical

				if ((i==0)&&(xc>posx))				// escaneo horizontal 0 grados
				{
					if ((xmin<=xc)&&(xc<=xmax)&&(ymin<=yc)&&(yc<=ymax))  // si corta a la recta dentro del segmento
					{
						nuevadis=sqrt((posx-xc)*(posx-xc)+(posy-yc)*(posy-yc));
						if (nuevadis<distancia)
							distancia=nuevadis;
					}
				}
				else if ((2*i==PUNTOSESCANEO)&&(xc<posx))	// escaneo horizontal 180 grados 
				{
					if ((xmin<=xc)&&(xc<=xmax)&&(ymin<=yc)&&(yc<=ymax))  // si corta a la recta dentro del segmento
					{
						nuevadis=sqrt((posx-xc)*(posx-xc)+(posy-yc)*(posy-yc));
						if (nuevadis<distancia)
							distancia=nuevadis;
					}

				}
				else if (((i>0)&&(2*i<PUNTOSESCANEO)&&(yc>=posy))||((2*i>PUNTOSESCANEO)&&(yc<=posy)))
				{
					if ((xmin<=xc)&&(xc<=xmax)&&(ymin<=yc)&&(yc<=ymax))	// si corta a la recta dentro del segmento
					{
						nuevadis=sqrt((posx-xc)*(posx-xc)+(posy-yc)*(posy-yc));
						if (nuevadis<distancia)
							distancia=nuevadis;
					}
				}
			}	
		}  // for l
		escaneo[puntero]=distancia;
		puntero++;
		puntero %= PUNTOSESCANEO;		
	}	// for i
	return 0;
}


// ***********************************************
// DIBUJA EL ARRAY RESULTADO DEL ESCANEO

int dibujaescaneo(float *escaneo)
{
	float angulo=0;
	float x,y;
	int i;

	gfx_clear(1);	// borra la ventana para dibujarla de nuevo
	// dibuja una marca roja indicando el centro, donde se ubica el robot
	gfx_color(1,240,0,0);
	gfx_line(1,200,200,200,210);
	
	gfx_color(1,0,200,100);		// color verde

	// dibuja un punto a la distancia de escaneo[i] en la orientacion correspondiente
	for(i=0;i<PUNTOSESCANEO;i++){
		y=escaneo[i]*cos(angulo);
		x=-escaneo[i]*sin(angulo);
		gfx_point(1,200+x,200-y);
		angulo+=(2.0*M_PI)/(float) PUNTOSESCANEO;
	}
	gfx_flush(1);

	return 0;

}


// *****************************************************************
// MAIN ARGUMENTOS LINEA DE COMANDOS OPCIONALES: TIEMPO MAXIMO EN SEGUNDOS, NOMBRE FICHERO GEOMETRIA

int main(int argc, char *argv[])
{
	int numlineas;				// numero de lineas de la geometria
	int resultado;				// resultado de llamada a funciones
	char c;
	float posx=XINICIAL;			// posicion x del robot
	float posy=YINICIAL;			// posicion y del robot
	float rumbo = RUMBOINICIAL;		// orientacion del robot en grados sexagesimales
	int i;
	float paso;				// contador del ciclo del main
	int ysize = 400;			// tamaño x de la ventana 1
	int xsize = 400;			// tamaño y de la ventana 1
	float tinicio;				// hora de inicio del programa
	float tiempo;				// tiempo de ejecucion transcurrido en milisegundos
        char* filename = NOMBREFICHERO;		// nombre del fichero que guarda la geometria de la habitacion
	float tmax=TMAX;			// tiempo maximo de ejecucion
	float posxa,posya;			// posicion previa del robot
	float tant=0.0;				// tiempo de ejecucion transcurrido en el ciclo anterior
	float angulo;		
	struct estadorobot estado;		// estado del robot devuelto por el algoritmo del robot

	printf("Uso: %s [<tiempo maximo>] [<rumbo inicial>] [<x inicial>] [<y inicial>] [<nombre fichero>]\n",argv[0]);
	if (argc>1)
		tmax=strtof(argv[1], NULL)*1000.0;
	if (argc>2)
		rumbo=strtof(argv[2], NULL);
	if (argc>3)
		posx=strtof(argv[3], NULL);
	if (argc>4)
		posy=strtof(argv[4], NULL);
	if (argc>5)
		numlineas=leefichero(argv[5],geometria);		
	else
		numlineas=leefichero(filename,geometria);

	printf("lineas: %d\n",numlineas);
	if (numlineas==0)
	{
		printf("Geometria vacia. Saliendo.\n");
		exit(0);
	}

	// INICIALIZA ARRAY DE TANGENTES DE LOS ANGULOS DE ESCANEO PARA HACER MAS RAPIDO EL ESCANEO
	for(i=0;i<PUNTOSESCANEO;i++)
	{
		angulo = (float) i*2.0*M_PI/((float) PUNTOSESCANEO);
		if ((angulo==M_PI/2.0)||(angulo==1.5*M_PI))
			t[i]=1.0e12; 	// no es pendiente infinita pero casi
		else
			t[i]=tan(angulo);
	}


	resultado=dibujageometria(numlineas,geometria);

	gfx_open(1,xsize,ysize,"Geometria escaneada");

	gfx_color(1,0,200,100);		// color verde en la ventana 1, de geometria escaneada

	gfx_open(2,PUNTOSESCANEO,ysize,"Plot del escaneado");

	gfx_color(2,0,200,100);		// color verde en la ventana 2, de geometria escaneada


	printf("t=%f x=%f y=%f rumbo=%f  INICIAL\n",tiempo,posx,posy,rumbo);

	tinicio=clock();

	for(paso=0.0;paso<tmax/PERIODO;paso++)
	{
		resultado=escanear(posx, posy, rumbo, escaneo, numlineas,geometria);

		resultado=dibujaescaneo(escaneo);
		resultado=plotescaneo(escaneo);

		delay((int) PERIODO);
		tiempo=(clock()-tinicio)/CLOCKS_PER_SEC;
		posxa=posx;
		posya=posy;

		estado = algoritmo_robot(tiempo,escaneo);

// reposicionamiento robot

		rumbo+=estado.velocidad_angular*(tiempo-tant);
		if (rumbo>360.0) rumbo-=360.0;
		if (rumbo<0.0) rumbo+=360.0;
		posx+=estado.velocidad_radial*cos(rumbo*M_PI/180.0)*(tiempo-tant);
		posy+=estado.velocidad_radial*sin(rumbo*M_PI/180.0)*(tiempo-tant);
		tant=tiempo;

		printf("t=%f x=%f y=%f rumbo=%f r=%s\n",tiempo,posx,posy,rumbo,estado.resultado);

		gfx_line(0,200+posxa,200-posya,200+posx,200-posy);	// trayectoria del robot en ventana 0
		gfx_flush(0);
	}
	
	c = gfx_wait(1);		// se queda esperando para que no se eliminen las ventanas 0 a 2

	exit(resultado);
}


