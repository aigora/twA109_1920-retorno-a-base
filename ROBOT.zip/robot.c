// ALGORITMO DE MOVIMIENTO DEL ROBOT **********************
// VERSION 1 5-5-2020
// devuelve un struct con
// .velocidad_radial
// .velocidad_angular
// .resultado - solo se utiliza para escribirlo en pantalla en escaner.c; puede ser cualquier valor (distancia, giro...)
// entrada: el tiempo transcurrido desde el inicio (el robot puede tener un reloj interno)
// el arrray de distancias escaneadas desde el frente del robot en 360 grados



#define VIDABATERIA 50 // en segundos, cuando queda la mitad, vuelve a posicion inicial
#define XINICIAL 0.0 // posicion y rumbo inicial, si no se dan en linea de comando
#define YINICIAL 0.0
#define RUMBOINICIAL 0.0

#include "escaner.c" // programa con escaneo, graficos, carga de geometria y bucle principal que llama a esta funcion


// funcion estadorobot

struct estadorobot algoritmo_robot(float tiempo, float *escaneo)
{


// VARIABLES DE ESTADO INTERNAS

static float velocidad=30.0; //variable para la velocidad de desplazamiento en linea recta
static float velang=0.0;     //variable para la velocidad de desplazamiento en el giro
static float tant=0.0;       
static int girando=0;        
static int sentidogiro=1;    //indica la direccion del giro (-1, contrario a las agujas del reloj, 1, senido de las agujasd del reloj)
static int cuentagiros=0;
static float posx=0.0;       //variables para que el robot(que establece su propio sistema de coordenadas, fijando su posicion en (0.0,0.0) ano coincidente con el de la habitación) pueda ir actualizando su posicion y sea capaz de volver al punto de inicio(base de carga)
static float posy=0.0;
static float rumbo=0.0;
static int obstaculo=0;      //indica la existencia de un obstaculo a menos de la distancia 20 y en un sector circular de 80 puntos 
static int cuenta=0;         

// OTRAS VARIABLE

int i;          //tamaño del sector circular (al frente del robot) en el que identificará un obstaculo
float d;
float angulo;                 
struct estadorobot estado;

// calculo distancia de obsatculos al frente

d=1000.0;                                                                                       //distancia maxima de escaneo(nunca llega)
for(i=0;i<80;i++)                                                                               //el sector circular es de 80 puntos de entre 1000 escaneados de los 360 grados(aprox 30 grados)
{                                                                                               //Se escanea del ángulo -40 al 40
if (escaneo[(PUNTOSESCANEO-40+i)%PUNTOSESCANEO]<d)                                              //de los 80 puntos que escanea se queda con el menor(la menor distancia)
	d=escaneo[(PUNTOSESCANEO-40+i)%PUNTOSESCANEO];
}

// calculo nuevas velocidades radiales y angulares

if (tiempo>VIDABATERIA)                           //Si el tiempo supera la vida de la bateria(150) el robot se dentendra
              {
                velocidad=0.0;
                velang=0.0;
                strcpy(estado.resultado,"SIN BATERIA");  //estado actualizado a sin bateria
               }
else if (tiempo<VIDABATERIA*2.0/3.0)           //estado de exploracion estandar, movimiento del robot          
{

if (d<20.0*(1.0+girando))                     //si detecta obstaculo, es decir, la distancia a uno de los 80 puntos es menor que 20
	{
	velocidad=0.0;
	velang=20.0*sentidogiro;
if (girando==0.0)
{
cuentagiros++;
}
girando=2.0;
}
else                                        //ya ha esquivado el obstaculo
{
velocidad=30.0;
velang=0.0;
girando=0.0;
                            //multiplicando el sentidogiro a -1 hara que gire a izd en las veces impares y a dcha las veces pares
}
strcpy(estado.resultado,"EXPLORANDO");


}
//EL RETORNO DEL REY jaja
else                                  //la bateria no se ha agotado pero el tiempo supera los 2/3 de la vida de la bateria, retorna a la base
{
angulo=180+atan2(posy,posx)*180.0/M_PI;

if (((angulo-rumbo)*(angulo-rumbo)>10)&&(obstaculo==0))
{
// APUNTANDO SI NO HAY OBSTACULO
	if (abs(angulo-rumbo)<180)     
	       {                                   //alinea y establece el rumbo apuntando a la posicion(0.0,0.0), punto de partida
	 	velang=20.0*(angulo-rumbo)/abs(angulo-rumbo);
	        }
	else 
		 {                                     
		velang=-20.0*(angulo-rumbo)/abs(angulo-rumbo);
	}
	velocidad=0.0;
	strcpy(estado.resultado,"FIJANDO RUMBO");                     
}
else if ((posx*posx+posy*posy)>10)
{
// ACERCANDO

	if (d<30.0)
	{
		// OBSTACULO A SALVAR
		// PRIMERO GIRA
		obstaculo=1;
		cuenta=0;
		velocidad=0.0;
		velang=10.0*sentidogiro;
		strcpy(estado.resultado,"OBSTACULO"); //si el robot se encuentra a una distancia determinada del obstáculo, se detendrá y comenzará a girar.
		 //en pantalla se mostrará "OBSTACULO".
	}
	else
	{
		// LUEGO AVANZA DURANTE UN 20 INTERVALOS //en caso de que la distancia sea mayor, el robot avanzará y en pantalla se mostrará "ACERCANDO" hasta que
		//el robot se encuentre un obstáculo, entonces se inicializará el comando anterior.
		cuenta++;
		velocidad=10.0;
		velang=0.0;
		strcpy(estado.resultado,"ACERCANDO");
		if (cuenta>20)
		obstaculo=0;
	}

}
else
{
// PARADO
velocidad=0.0; //cuando la batería llega a su fin el robot se para (velocidad angular=0;velocidad radial=0) y en pantalla
//aparecerá "PARADO"
velang=0.0;
strcpy(estado.resultado,"PARADO");

}
}

estado.velocidad_radial=velocidad;
estado.velocidad_angular=velang;

//


// ACTUALIZA POSICION Y RUMBO
rumbo+=estado.velocidad_angular*(tiempo-tant);
if (rumbo>360.0) rumbo-=360.0; //para evitar problemas en la conversión de los grados se suma o 360 grados
if (rumbo<-360.0) rumbo+=360.0;
posx+=estado.velocidad_radial*cos(rumbo*M_PI/180.0)*(tiempo-tant);
posy+=estado.velocidad_radial*sin(rumbo*M_PI/180.0)*(tiempo-tant);
tant=tiempo;       

return estado;

}
